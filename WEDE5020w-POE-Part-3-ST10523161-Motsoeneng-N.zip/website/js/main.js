/* ========================================
   Main JavaScript File
   ======================================== */

// Wait for DOM to load
document.addEventListener('DOMContentLoaded', function() {
    
    /* ========================================
       Mobile Hamburger Menu
       ======================================== */
    const hamburger = document.querySelector('.hamburger');
    const navMenu = document.querySelector('nav ul');
    
    if (hamburger) {
        hamburger.addEventListener('click', function() {
            hamburger.classList.toggle('active');
            navMenu.classList.toggle('active');
        });
    }
    
    // Close menu when a link is clicked
    const navLinks = document.querySelectorAll('nav ul li a');
    navLinks.forEach(link => {
        link.addEventListener('click', function() {
            hamburger.classList.remove('active');
            navMenu.classList.remove('active');
        });
    });
    
    /* ========================================
       Form Validation - Contact Form (Homepage)
       ======================================== */
    const contactForm = document.getElementById('contactForm');
    
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form fields
            const name = document.getElementById('name');
            const email = document.getElementById('email');
            const phone = document.getElementById('phone');
            const subject = document.getElementById('subject');
            const message = document.getElementById('message');
            
            let isValid = true;
            
            // Validate name
            if (name.value.trim().length < 2) {
                showError(name, 'Please enter your full name');
                isValid = false;
            } else {
                removeError(name);
            }
            
            // Validate email
            const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
            if (!emailRegex.test(email.value.trim())) {
                showError(email, 'Please enter a valid email address');
                isValid = false;
            } else {
                removeError(email);
            }
            
            // Validate phone (South African format)
            const phoneRegex = /^(\+27|0)[6-8][0-9]{8}$/;
            if (!phoneRegex.test(phone.value.trim().replace(/\s/g, ''))) {
                showError(phone, 'Please enter a valid South African phone number');
                isValid = false;
            } else {
                removeError(phone);
            }
            
            // Validate subject
            if (subject.value === '') {
                showError(subject, 'Please select a subject');
                isValid = false;
            } else {
                removeError(subject);
            }
            
            // Validate message
            if (message.value.trim().length < 10) {
                showError(message, 'Please enter a message (at least 10 characters)');
                isValid = false;
            } else {
                removeError(message);
            }
            
            if (isValid) {
                // Simulate form submission
                const submitBtn = contactForm.querySelector('button[type="submit"]');
                const originalText = submitBtn.textContent;
                submitBtn.textContent = 'Sending...';
                submitBtn.disabled = true;
                
                setTimeout(function() {
                    alert('Thank you for your message! We will get back to you within 24 hours.');
                    contactForm.reset();
                    submitBtn.textContent = originalText;
                    submitBtn.disabled = false;
                }, 1500);
            }
        });
    }
    
    /* ========================================
       Form Validation - Booking Form
       ======================================== */
    const bookingForm = document.getElementById('bookingForm');
    
    if (bookingForm) {
        bookingForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const name = document.getElementById('booking-name');
            const email = document.getElementById('booking-email');
            const phone = document.getElementById('booking-phone');
            const service = document.getElementById('booking-service');
            const date = document.getElementById('booking-date');
            const time = document.getElementById('booking-time');
            const location = document.getElementById('booking-location');
            const agree = document.getElementById('booking-agree');
            
            let isValid = true;
            
            // Validate name
            if (name.value.trim().length < 2) {
                showError(name, 'Please enter your full name');
                isValid = false;
            } else {
                removeError(name);
            }
            
            // Validate email
            const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
            if (!emailRegex.test(email.value.trim())) {
                showError(email, 'Please enter a valid email address');
                isValid = false;
            } else {
                removeError(email);
            }
            
            // Validate phone
            const phoneRegex = /^(\+27|0)[6-8][0-9]{8}$/;
            if (!phoneRegex.test(phone.value.trim().replace(/\s/g, ''))) {
                showError(phone, 'Please enter a valid South African phone number');
                isValid = false;
            } else {
                removeError(phone);
            }
            
            // Validate service
            if (service.value === '') {
                showError(service, 'Please select a service');
                isValid = false;
            } else {
                removeError(service);
            }
            
            // Validate date
            if (date.value === '') {
                showError(date, 'Please select a date');
                isValid = false;
            } else {
                removeError(date);
            }
            
            // Validate time
            if (time.value === '') {
                showError(time, 'Please select a time');
                isValid = false;
            } else {
                removeError(time);
            }
            
            // Validate location
            if (location.value.trim().length < 5) {
                showError(location, 'Please enter your full address');
                isValid = false;
            } else {
                removeError(location);
            }
            
            // Validate agreement
            if (!agree.checked) {
                showError(agree, 'You must agree to be contacted');
                isValid = false;
            } else {
                removeError(agree);
            }
            
            if (isValid) {
                const submitBtn = bookingForm.querySelector('button[type="submit"]');
                const originalText = submitBtn.textContent;
                submitBtn.textContent = 'Preparing Email...';
                submitBtn.disabled = true;

                // Compile the form data into an email
                const recipient = 'abccarwashservices12@gmail.com';
                const emailSubject = encodeURIComponent(`New Booking Request: ${name.value.trim()}`);
                const emailBody = encodeURIComponent(
                    `--- NEW BOOKING REQUEST ---\n\n` +
                    `Name: ${name.value}\n` +
                    `Email: ${email.value}\n` +
                    `Phone: ${phone.value}\n` +
                    `Service: ${service.value}\n` +
                    `Date: ${date.value}\n` +
                    `Time: ${time.value}\n` +
                    `Location: ${location.value}\n` +
                    `Notes: ${document.getElementById('booking-notes').value || 'None'}\n`
                );

                // Open the user's email client
                window.location.href = `mailto:${recipient}?subject=${emailSubject}&body=${emailBody}`;

                // Reset the form after a brief delay
                setTimeout(function() {
                    alert('Your email app has been opened. Please click "Send" in your email app to complete the booking.');
                    bookingForm.reset();
                    submitBtn.textContent = originalText;
                    submitBtn.disabled = false;
                }, 500);
            }
        });
    }
    
    /* ========================================
       Form Validation - Quote Form
       ======================================== */
    const quoteForm = document.getElementById('quoteForm');
    
    if (quoteForm) {
        const quoteType = document.getElementById('quote-type');
        const frequency = document.getElementById('quote-frequency');
        const dynamicFields = document.createElement('div');
        const dynamicFieldValues = new Map();
        const statusMessage = document.createElement('p');

        dynamicFields.className = 'quote-dynamic-fields';
        quoteType.parentNode.insertAdjacentElement('afterend', dynamicFields);
        statusMessage.className = 'quote-form-status';
        statusMessage.setAttribute('role', 'status');
        statusMessage.setAttribute('aria-live', 'polite');
        statusMessage.hidden = true;
        quoteForm.querySelector('button[type="submit"]').insertAdjacentElement('beforebegin', statusMessage);

        function createRequiredField(name, labelText, placeholder) {
            const group = document.createElement('div');
            const label = document.createElement('label');
            const input = document.createElement('input');

            group.className = 'form-group';
            input.type = 'text';
            input.id = `quote-${name}`;
            input.name = name;
            input.required = true;
            input.placeholder = placeholder;
            label.htmlFor = input.id;
            label.textContent = labelText;
            group.append(label, input);

            if (dynamicFieldValues.has(name)) {
                input.value = dynamicFieldValues.get(name);
            }

            return { group, input };
        }

        function updateDynamicFields() {
            dynamicFields.querySelectorAll('input').forEach(input => {
                dynamicFieldValues.set(input.name, input.value);
            });
            dynamicFields.replaceChildren();

            const businessTypes = ['fleet', 'corporate', 'school', 'estate'];
            if (businessTypes.includes(quoteType.value)) {
                const field = createRequiredField(
                    'organization',
                    'Business, school, or estate name',
                    'Enter the organization name'
                );
                dynamicFields.appendChild(field.group);
            } else if (quoteType.value === 'other') {
                const field = createRequiredField(
                    'quote-details',
                    'Please describe the type of quote you need',
                    'Tell us what you have in mind'
                );
                dynamicFields.appendChild(field.group);
            }

            if (frequency.value === 'custom') {
                const field = createRequiredField(
                    'custom-frequency',
                    'Describe your preferred schedule',
                    'For example, every 10 days'
                );
                dynamicFields.appendChild(field.group);
            }

        }

        quoteForm.addEventListener('change', function(event) {
            if (event.target === quoteType || event.target === frequency) {
                updateDynamicFields();
            }
        });
        updateDynamicFields();

        quoteForm.addEventListener('submit', function(e) {
            e.preventDefault();
            statusMessage.hidden = true;
            statusMessage.textContent = '';
            statusMessage.removeAttribute('data-state');
            
            const name = document.getElementById('quote-name');
            const email = document.getElementById('quote-email');
            const phone = document.getElementById('quote-phone');
            const vehicles = document.getElementById('quote-vehicles');
            const location = document.getElementById('quote-location');
            
            let isValid = true;
            
            // Validate name
            if (name.value.trim().length < 2) {
                showError(name, 'Please enter your full name');
                isValid = false;
            } else {
                removeError(name);
            }
            
            // Validate email
            const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
            if (!emailRegex.test(email.value.trim())) {
                showError(email, 'Please enter a valid email address');
                isValid = false;
            } else {
                removeError(email);
            }
            
            // Validate phone
            const phoneRegex = /^(\+27|0)[6-8][0-9]{8}$/;
            if (!phoneRegex.test(phone.value.trim().replace(/\s/g, ''))) {
                showError(phone, 'Please enter a valid South African phone number');
                isValid = false;
            } else {
                removeError(phone);
            }
            
            // Validate quote type
            if (quoteType.value === '') {
                showError(quoteType, 'Please select a quote type');
                isValid = false;
            } else {
                removeError(quoteType);
            }
            
            // Validate vehicles
            if (vehicles.value < 1) {
                showError(vehicles, 'Please enter at least 1 vehicle');
                isValid = false;
            } else {
                removeError(vehicles);
            }
            
            // Validate location
            if (location.value.trim().length < 5) {
                showError(location, 'Please enter your service location');
                isValid = false;
            } else {
                removeError(location);
            }

            dynamicFields.querySelectorAll('input[required]').forEach(field => {
                if (!field.value.trim()) {
                    showError(field, 'Please complete this field');
                    isValid = false;
                } else {
                    removeError(field);
                }
            });
            
            if (!isValid) {
                statusMessage.textContent = 'Please correct the highlighted fields and try again.';
                statusMessage.dataset.state = 'error';
                statusMessage.hidden = false;
                const firstInvalidField = quoteForm.querySelector('[aria-invalid="true"]');
                if (firstInvalidField) {
                    firstInvalidField.focus();
                    firstInvalidField.scrollIntoView({ behavior: 'smooth', block: 'center' });
                }
                return;
            }

            if (isValid) {
                const submitBtn = quoteForm.querySelector('button[type="submit"]');
                const originalText = submitBtn.textContent;
                submitBtn.textContent = 'Submitting...';
                submitBtn.disabled = true;
                statusMessage.textContent = 'Preparing your quote request...';
                statusMessage.dataset.state = 'pending';
                statusMessage.hidden = false;
                
                setTimeout(function() {
                    quoteForm.reset();
                    dynamicFieldValues.clear();
                    dynamicFields.replaceChildren();
                    updateDynamicFields();
                    submitBtn.textContent = originalText;
                    submitBtn.disabled = false;
                    statusMessage.textContent = 'Your request is submitted, we will get back to you in the next 24 hours.';
                    statusMessage.dataset.state = 'success';
                }, 1500);
            }
        });
    }
    
    /* ========================================
       Form Validation - Contact Page Form
       ======================================== */
    const contactFormPage = document.getElementById('contactFormPage');
    
    if (contactFormPage) {
        contactFormPage.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const name = document.getElementById('contact-name');
            const email = document.getElementById('contact-email');
            const phone = document.getElementById('contact-phone');
            const subject = document.getElementById('contact-subject');
            const message = document.getElementById('contact-message');
            
            let isValid = true;
            
            if (name.value.trim().length < 2) {
                showError(name, 'Please enter your full name');
                isValid = false;
            } else {
                removeError(name);
            }
            
            const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
            if (!emailRegex.test(email.value.trim())) {
                showError(email, 'Please enter a valid email address');
                isValid = false;
            } else {
                removeError(email);
            }
            
            const phoneRegex = /^(\+27|0)[6-8][0-9]{8}$/;
            if (!phoneRegex.test(phone.value.trim().replace(/\s/g, ''))) {
                showError(phone, 'Please enter a valid South African phone number');
                isValid = false;
            } else {
                removeError(phone);
            }
            
            if (subject.value === '') {
                showError(subject, 'Please select a subject');
                isValid = false;
            } else {
                removeError(subject);
            }
            
            if (message.value.trim().length < 10) {
                showError(message, 'Please enter a message (at least 10 characters)');
                isValid = false;
            } else {
                removeError(message);
            }
            
            if (isValid) {
                const submitBtn = contactFormPage.querySelector('button[type="submit"]');
                submitBtn.textContent = 'Preparing Email...';

                const recipient = 'abccarwashservices12@gmail.com';
                const subject = encodeURIComponent(`Contact Form: ${subject.value}`);
                const body = encodeURIComponent(
                    `--- NEW CONTACT MESSAGE ---\n\n` +
                    `Name: ${name.value}\n` +
                    `Email: ${email.value}\n` +
                    `Phone: ${phone.value}\n` +
                    `Subject: ${subject.value}\n\n` +
                    `Message:\n${message.value}\n`
                );

                window.location.href = `mailto:${recipient}?subject=${subject}&body=${body}`;

                setTimeout(() => {
                    alert('Your email app has been opened. Please click "Send" to deliver your message.');
                    contactFormPage.reset();
                    submitBtn.textContent = 'Send Message';
                }, 500);
            }

        });
    }
    
    /* ========================================
       Show Error Function
       ======================================== */
    function showError(input, message) {
        // Remove existing error
        removeError(input);
        
        // Add error class to input
        input.style.borderColor = '#e74c3c';
        input.setAttribute('aria-invalid', 'true');
        
        // Create error message
        const error = document.createElement('span');
        error.className = 'error-message';
        error.style.color = '#e74c3c';
        error.style.fontSize = '0.8rem';
        error.style.display = 'block';
        error.style.marginTop = '5px';
        error.textContent = message;
        
        // Insert after input
        input.parentNode.appendChild(error);
    }
    
    /* ========================================
       Remove Error Function
       ======================================== */
    function removeError(input) {
        input.style.borderColor = '';
        input.removeAttribute('aria-invalid');
        const error = input.parentNode.querySelector('.error-message');
        if (error) {
            error.remove();
        }
    }
    
    /* ========================================
       Smooth Scroll for Anchor Links
       ======================================== */
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            const href = this.getAttribute('href');
            if (href !== '#') {
                const target = document.querySelector(href);
                if (target) {
                    e.preventDefault();
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            }
        });
    });
    
    /* ========================================
       Gallery Lightbox Functionality (Preview)
       ======================================== */
    const lightbox = document.createElement('div');
    lightbox.id = 'lightbox';
    document.body.appendChild(lightbox);
    
    const galleryGrid = document.querySelectorAll('.gallery-grid .gallery-item');
    
    galleryGrid.forEach(item => {
        item.addEventListener('click', e => {
            lightbox.classList.add('active');
            const img = e.currentTarget.querySelector('img');
            while (lightbox.firstChild) {
                lightbox.removeChild(lightbox.firstChild);
            }
            lightbox.appendChild(img.cloneNode(true));
        });
    });
    
    lightbox.addEventListener('click', e => {
        if (e.target !== e.currentTarget) return;
        lightbox.classList.remove('active');
    });
    
    /* ========================================
    Gallery Lightbox Functionality (Services Page)
    ======================================== */
    const serviceLightbox = document.createElement('div');
    serviceLightbox.id = 'service-lightbox';
    document.body.appendChild(serviceLightbox);

    const serviceItemImage = document.querySelectorAll('.service-item .service-item-image');

    serviceItemImage.forEach(img => {
        img.addEventListener('click', e => {
            serviceLightbox.classList.add('active');
            const img = e.currentTarget.querySelector('img');
            while (serviceLightbox.firstChild) {
                serviceLightbox.removeChild(serviceLightbox.firstChild);
            }
            serviceLightbox.appendChild(img.cloneNode(true));
        });
    });

    serviceLightbox.addEventListener('click', e => {
        if (e.target !== e.currentTarget) return;
        serviceLightbox.classList.remove('active');
    });

    /* ========================================
    Gallery Lightbox Functionality (Gallery Page)
    ======================================== */
    const galleryLightbox = document.createElement('div');
    galleryLightbox.id = 'gallery-lightbox';
    document.body.appendChild(galleryLightbox);

    const galleryImages = document.querySelectorAll('.gallery-card .gallery-card-image');

    galleryImages.forEach(img => {
        img.addEventListener('click', e => {
            galleryLightbox.classList.add('active');
            const img = e.currentTarget.querySelector('img');
            while (galleryLightbox.firstChild) {
                galleryLightbox.removeChild(galleryLightbox.firstChild);
            }
            galleryLightbox.appendChild(img.cloneNode(true));
        });
    });

    galleryLightbox.addEventListener('click', e => {
        if (e.target !== e.currentTarget) return;
        galleryLightbox.classList.remove('active');
    });

    const galleryFilterButtons = document.querySelectorAll('.filter-btn[data-filter]');
    const galleryCards = document.querySelectorAll('.gallery-card[data-category]');

    galleryFilterButtons.forEach(button => {
        button.addEventListener('click', function() {
            const filter = button.dataset.filter;

            galleryFilterButtons.forEach(filterButton => {
                const isActive = filterButton === button;
                filterButton.classList.toggle('active', isActive);
                filterButton.setAttribute('aria-pressed', String(isActive));
            });

            galleryCards.forEach(card => {
                const category = card.dataset.category;
                const isVisible = filter === 'all' ||
                    (filter === 'before-after' && ['before', 'after'].includes(category)) ||
                    category === filter;

                card.hidden = !isVisible;
            });
        });
    });

     /* ========================================
        Dynamic Content- Service Search & Filter
        ======================================== */
    const searchInput = document.getElementById('serviceSearch');
    if (searchInput) {
        const searchableItems = document.querySelectorAll(
            '.price-table tbody tr, .service-item, .package-card'
        );
        const noResults = document.getElementById('noResults');

        searchInput.addEventListener('input', function(e) {
            const query = e.target.value.trim().toLowerCase();
            let visibleCount = 0;

            searchableItems.forEach(item => {
                const text = item.textContent.toLowerCase();
                if (text.includes(query)) {
                    item.style.display = ''; // Show
                    visibleCount++;
                } else {
                    item.style.display = 'none'; // Hide
                }
            });

            // Show/hide "No results" message
            if (noResults) {
                noResults.style.display = visibleCount === 0 ? 'block' : 'none';
            }
        });
    }

    // Debug flag: set to true to enable console logs for debugging
    const DEBUG = false;
    if (DEBUG) {
        console.log('ABC Carwash Services - Website Loaded Successfully!');
    }
});